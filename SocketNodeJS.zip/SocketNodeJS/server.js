const express = require('express');
const path = require('path');

const app = express();
const server = require('http').createServer(app);
const io = require('socket.io')(server);

app.use(express.static(path.join(__dirname,'public')));
app.set('views',path.join(__dirname,'public'));
app.engine('html',require('ejs').renderFile);
app.set('view engine','html');

app.use('/',(req,res)=>{
    res.render('index.html');
});


let socket_usuarios = [];
//console.log(`SOCKET CONECTADO: ${socket.id}`);

    //socket.emit('mensagensAnteriores',historicoMensagens);

    // A opção "on" fica ouvindo, como fosse um listener do Java.
    // "informacao" deve existir no código do cliente dentro de um "emit".
        
    //console.log(valores);

    // A opção "broadcast.emit" envia para todos os sockets clientes menos para quem mandou a mensagem original:
    //socket.broadcast.emit('dadosServidor',valores);

io.on('connection',socket =>
{
        let achou=0;
        for (cadaUsuario of socket_usuarios)
        {
            if(cadaUsuario == socket.id)
            {
                achou=1;
            }
        }
        if(achou==0)
        {
            socket_usuarios.push(socket.id);
            socket.emit('soc_individual',socket_usuarios,socket.id);
            io.sockets.emit('soc',socket_usuarios,socket.id);
            console.log("Novo usuário: "+socket.id);
        }


        socket.on('orientacao',data =>
        {
            for (cadaUsuario of socket_usuarios)
            {
                if(cadaUsuario == socket.id)
                {
                    let valores = {
                    'usuario':cadaUsuario,
                    'x':data.x,
                    'z':data.z
                    };
                    io.sockets.emit('nova_orientacao',valores);
                    console.log("ENVIADO PARA TODOS: "+valores);
                }
            }
        
        });
});

server.listen(3000);